package com.example.welcomechat;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

@Mod("welcomechat")
public class WelcomeChat {

    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            player.sendSystemMessage(
                Component.literal(
                    "Hallo " + player.getName().getString() + ",\n" +
                    "willkommen auf diesem Server!"
                )
            );
        }
    }
}
